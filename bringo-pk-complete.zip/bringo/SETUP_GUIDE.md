# Bringo.pk — Complete Setup & Deployment Guide
**For non-developers — step by step, zero coding knowledge required.**

---

## 📁 FILES IN YOUR PROJECT

```
bringo/
├── index.html          ← The main website
├── style.css           ← All the styling
├── app.js              ← Form logic & Google Sheets connection
├── google-apps-script.js  ← Backend (goes into Google Apps Script)
└── SETUP_GUIDE.md      ← This file
```

---

## PART 1: SET UP GOOGLE SHEETS (DATABASE)

### Step 1 — Create the Spreadsheet
1. Go to **https://sheets.google.com**
2. Click the **"+"** button to create a new blank spreadsheet
3. Name it: **"Bringo.pk Orders"** (click on "Untitled spreadsheet" at top left)
4. At the bottom, you'll see tabs. Click the **"+"** to add a second tab
5. Rename the first tab to: `Grocery Orders`
6. Rename the second tab to: `Clothing Orders`
7. **Copy the Spreadsheet ID** from the URL:
   - URL looks like: `https://docs.google.com/spreadsheets/d/`**`1BxiMVs0XRA5nFMdKvBdBZjgmUUqptlbs74OgVE2upms`**`/edit`
   - The bold part between `/d/` and `/edit` is your **Spreadsheet ID**
   - Save this — you'll need it in Step 3

---

### Step 2 — Open Apps Script
1. In your Google Sheet, click the top menu: **Extensions → Apps Script**
2. A new tab opens with a code editor
3. Delete everything in the editor (Ctrl+A then Delete)
4. Open the file `google-apps-script.js` from this project (open it in Notepad or any text editor)
5. **Copy all the code** and paste it into the Apps Script editor

---

### Step 3 — Add Your Spreadsheet ID
1. In the Apps Script editor, find this line near the top:
   ```
   const SPREADSHEET_ID = "YOUR_SPREADSHEET_ID_HERE";
   ```
2. Replace `YOUR_SPREADSHEET_ID_HERE` with the ID you copied in Step 1
3. Example: `const SPREADSHEET_ID = "1BxiMVs0XRA5nFMdKvBdBZjgmUUqptlbs74OgVE2upms";`

---

### Step 4 — Deploy as Web App
1. Click **Save** (💾 icon) or press Ctrl+S
2. Click the blue **"Deploy"** button (top right)
3. Select **"New deployment"**
4. Click the gear ⚙️ icon next to "Type" → select **"Web app"**
5. Fill in the settings:
   - **Description:** Bringo.pk Backend
   - **Execute as:** Me (your email)
   - **Who has access:** Anyone
6. Click **"Deploy"**
7. If asked to authorize, click **"Authorize access"** → choose your Google account → click **"Allow"**
8. You'll see a **Web app URL** — it looks like:
   `https://script.google.com/macros/s/AKfycbxXXX.../exec`
9. **Copy this URL** — you need it next!

---

### Step 5 — Connect to Your Website
1. Open the file `app.js` in Notepad (right-click → Open with → Notepad)
2. Find this line near the top:
   ```javascript
   const GOOGLE_SCRIPT_URL = "https://script.google.com/macros/s/YOUR_SCRIPT_ID_HERE/exec";
   ```
3. Replace the entire URL with the Web App URL you copied
4. Save the file (Ctrl+S)

---

### Step 6 — Test the Connection
1. Back in Apps Script, find the function selector dropdown (says "Select function")
2. Choose **"testGrocerySubmission"**
3. Click the ▶ Run button
4. Go back to your Google Sheet — you should see a test row in "Grocery Orders"!
5. Repeat with **"testClothingSubmission"** to test clothing orders

---

## PART 2: DEPLOY YOUR WEBSITE (FREE on Netlify)

### Step 1 — Create a Netlify Account
1. Go to **https://www.netlify.com**
2. Click **"Sign up"** → Choose **"Sign up with Email"**
3. Enter your email and create a password
4. Verify your email

---

### Step 2 — Deploy Your Site
**Method A: Drag & Drop (Easiest — no coding needed)**

1. Make sure all 3 files are in the same folder:
   - `index.html`
   - `style.css`
   - `app.js`
2. Log into Netlify
3. On the dashboard, scroll down to find the **drag-and-drop zone**:
   *"Want to deploy a new site without connecting to Git? Drag and drop your site output folder here"*
4. **Drag your entire project folder** onto that zone
5. Wait 10-20 seconds — your site is live! 🎉
6. Netlify gives you a random URL like: `https://amazing-bringo-123.netlify.app`

---

### Step 3 — Set a Custom Subdomain (Optional)
1. In Netlify, go to your site
2. Click **"Site settings"**
3. Under **"Site information"** → click **"Change site name"**
4. Type: `bringo-pk` → Save
5. Your site will be at: `https://bringo-pk.netlify.app`

---

### Step 4 — Connect a Custom Domain (bringo.pk)
If you own the domain `bringo.pk`:
1. In Netlify → Site settings → **Domain management** → **Add custom domain**
2. Type: `bringo.pk` → Click Verify
3. Follow the DNS instructions Netlify provides
4. Update your domain's DNS settings with your domain registrar (PKNIC, etc.)
5. SSL certificate is automatically added (HTTPS) — takes 5-10 minutes

---

## PART 3: UPDATE YOUR SITE

Whenever you make changes to `index.html`, `style.css`, or `app.js`:
1. Save your files
2. Go to Netlify → your site
3. Click **"Deploys"** tab
4. Drag your updated folder onto the deploy zone again
5. New version goes live in seconds ✅

---

## PART 4: MANAGING ORDERS

### View New Orders
1. Open your Google Sheet: **"Bringo.pk Orders"**
2. Click the **"Grocery Orders"** tab to see grocery submissions
3. Click the **"Clothing Orders"** tab for clothing orders
4. Each row = one customer order with timestamp

### Update Order Status
- The last column is "Status"
- Change it from "New" to "Confirmed", "Delivered", etc.
- You can use Google Sheets' color coding for visual tracking

### Get Notified of New Orders
1. In Google Sheets, click **Tools → Notification rules**
2. Select **"Any changes are made"**
3. Choose **"Email - right away"**
4. You'll get an email every time a new order comes in!

---

## PART 5: WHATSAPP NUMBER UPDATE

If your WhatsApp number changes:
1. Open `index.html` in Notepad
2. Press Ctrl+F and search for: `923258734745`
3. Replace all instances with your new number (format: country code + number, no spaces)
4. Save and re-upload to Netlify

---

## 🚨 TROUBLESHOOTING

**Problem: Form submits but nothing appears in Google Sheets**
- Make sure you replaced `YOUR_SPREADSHEET_ID_HERE` in the Apps Script
- Make sure you replaced `YOUR_SCRIPT_ID_HERE` in `app.js`
- Try redeploying the Apps Script (Deploy → Manage deployments → Edit → Update)

**Problem: "Something went wrong" error on form submit**
- The script URL in `app.js` might be wrong
- Make sure Apps Script is deployed as "Anyone" can access

**Problem: Website looks broken after upload**
- Make sure `index.html`, `style.css`, AND `app.js` are all in the same folder
- All 3 files must be uploaded together

**Problem: Google Fonts not loading**
- The site needs internet connection to load fonts
- This is normal — fonts load from Google's servers

---

## 📞 SUPPORT

If you need help, contact Mirsol Technologies or reach out to your developer.

**Bringo.pk Customer Support: 0325-8734745**

---

*Developed by Mirsol Technologies*
